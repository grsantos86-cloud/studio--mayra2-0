# Studio Mayra 2.0 — BuildPack GitHub Ready
Use este arquivo .tar.gz para enviar ao GitHub.
1. Vá ao repositório e clique em Add file → Upload files.
2. Envie este arquivo.
3. Clique em Commit changes.
4. Após o upload, vá em Actions → Flutter Android Build → Run workflow.
5. Baixe o app-debug.apk em Artifacts.
